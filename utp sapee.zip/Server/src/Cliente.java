import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.net.UnknownHostException;

public class Cliente {

	public static void main(String[] args) {
		try {
			DatagramSocket socket = new DatagramSocket();
			
			InetAddress serverIp = InetAddress.getByName("127.0.0.1");
			
			String mensaje = "holaaaaa";
			DatagramPacket datagrama = new DatagramPacket(mensaje.getBytes(), mensaje.getBytes().length, serverIp, 5000);
			
			socket.send(datagrama);
			
			byte[] buffer = new byte[1000];
			DatagramPacket datagrama_respuesta = new DatagramPacket(buffer, buffer.length);
			socket.receive(datagrama_respuesta);
			
			System.out.println("MENSAJE: " + new String(datagrama_respuesta.getData()));
			
			socket.close();
			
		} catch (SocketException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (UnknownHostException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
