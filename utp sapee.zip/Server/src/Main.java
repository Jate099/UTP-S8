import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;

public class Main {

	public static void main(String[] args) {
		try {
			//por medio de este puerto me comunico
			DatagramSocket socket = new DatagramSocket(5000);
			
			//Recibir mensaje
			byte[] buffer = new byte[1000];
			DatagramPacket datagrama = new DatagramPacket(buffer, buffer.length);
			
			System.out.println("espareando mesnaje...");
			//Este metodo va a estar congelado hasta que encuentre un mensaje
			socket.receive(datagrama);
			
			System.out.println(new String(datagrama.getData()));
			
			//responder al cliente
			String respuesta = "eeeeeh sapbeee";
			
			DatagramPacket datagrama_respuesta = new DatagramPacket(respuesta.getBytes(), respuesta.getBytes().length, datagrama.getAddress(), datagrama.getPort());
			socket.send(datagrama_respuesta);
			
			
			socket.close();
			
		} catch (SocketException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
